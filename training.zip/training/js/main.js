$("#mobilemenu").click (function(){
    $(".navbarmenu").addClass("active");
});

$(".close-icon").click (function(){
    $(".navbarmenu").removeClass("active");
});

$('#homeBanner').owlCarousel({
    loop:true,
    margin:0,
    nav:true,
    dots:false,
    items:1,
    navText: ["<i class='arrow left'></i>","<i class='arrow right'></i>"]
   
});

$('#newLaunch').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    dots:false,
    navText: ["<i class='arrow left'></i>","<i class='arrow right'></i>"],
    responsive:{
        0:{
            items:2.1
        },
        600:{
            items:2.5
        },
        1000:{
            items:4
        }
    }
});

$('#primedaystories').owlCarousel({
    loop:true,
    margin:15,
    nav:true,
    dots:false,
    navText: ["<i class='arrow left'></i>","<i class='arrow right'></i>"],
    responsive:{
        0:{
            items:1.5
        },
        600:{
            items:2.5
        },
        1000:{
            items:4
        }
    }
});

$('#primedayvideos').owlCarousel({
    loop:true,
    margin:15,
    nav:true,
    dots:false,
    navText: ["<i class='arrow left'></i>","<i class='arrow right'></i>"],
    responsive:{
        0:{
            items:1.5
        },
        600:{
            items:2.5
        },
        1000:{
            items:4
        }
    }
});

$('#socialmedia').owlCarousel({
    loop:true,
    margin:15,
    nav:true,
    dots:false,
    navText: ["<i class='arrow left'></i>","<i class='arrow right'></i>"],
    responsive:{
        0:{
            items:1.5
        },
        600:{
            items:2.5
        },
        1000:{
            items:4
        }
    }
});