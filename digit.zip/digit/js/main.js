$('#homeBanner').owlCarousel({
    loop:true,
    margin:0,
    nav:true,
    dots:false,
    items:1,
    navText: ["<i class='arrow left'></i>","<i class='arrow right'></i>"]
   
})